select 'region', count(*) from region;
select 'nation', count(*) from nation;
select 'nation', count(*) from nation;
select 'supplier', count(*) from supplier;
select 'customer', count(*) from customer;
select 'part', count(*) from part;
select 'partsupp',count(*) from partsupp;
select 'orders',count(*) from orders;
select 'lineitem', count(*) from lineitem;
